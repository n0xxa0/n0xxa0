# 🌐 Mon Site Personnel — Guide de déploiement

Un site web adaptatif avec :
- 🔗 Réseaux sociaux
- 👤 Section "À propos"
- ❓ FAQ interactive avec notifications email

---

## 📁 Structure du projet

```
portfolio-site/
├── index.html              ← Page principale (modifie tes infos ici)
├── src/
│   ├── app.js              ← Logique Firebase + FAQ (modifie ta config ici)
│   └── styles/
│       └── main.css        ← Styles (modifie si besoin)
├── .github/
│   └── workflows/
│       └── deploy.yml      ← Déploiement auto sur GitHub Pages
└── README.md               ← Ce fichier
```

---

## ✏️ ÉTAPE 1 — Personnalise le site

### Dans `index.html` :
1. **Ton nom** → Cherche `Votre Nom` et `YN` (initiales)
2. **Ta description** → Cherche les balises `<!-- ✏️ MODIFIE CE TEXTE -->`
3. **Tes réseaux** → Cherche `<!-- ✏️ REMPLACE LES LIENS -->` et change les `href` et `@TONPSEUDO`
4. **Tes tags** → Cherche `<!-- ✏️ MODIFIE LES TAGS -->`
5. **Ta photo** → Dans `.about-img-placeholder`, remplace le `<span>Photo</span>` par `<img src="ta-photo.jpg" alt="Toi" />`

---

## 🔥 ÉTAPE 2 — Configurer Firebase (base de données questions)

### 2.1 Créer le projet Firebase
1. Va sur [console.firebase.google.com](https://console.firebase.google.com)
2. Clique **"Créer un projet"** → nom : `mon-site-perso`
3. Désactive Google Analytics (optionnel) → Créer

### 2.2 Activer Firestore
1. Dans le menu gauche → **Firestore Database**
2. Clique **"Créer une base de données"**
3. Choisis **"Commencer en mode test"** (30 jours)
4. Sélectionne la région `europe-west1`

### 2.3 Règles Firestore (sécurité)
Dans Firestore → onglet **Règles**, remplace par :
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /questions/{questionId} {
      allow read: if true;
      allow create: if request.resource.data.keys().hasAll(['name','email','question','wantsNotif'])
                    && request.resource.data.name is string
                    && request.resource.data.name.size() <= 50
                    && request.resource.data.question is string
                    && request.resource.data.question.size() <= 500;
      allow update, delete: if false; // Uniquement via l'admin
    }
  }
}
```

### 2.4 Récupérer la config
1. Dans Firebase → ⚙️ **Paramètres du projet** → onglet **Général**
2. Descends jusqu'à "Vos applications" → Clique **</>** (Web)
3. Nom : `mon-site` → Enregistrer
4. Copie le bloc `const firebaseConfig = {...}`

### 2.5 Coller dans app.js
Dans `src/app.js`, remplace le bloc `FIREBASE_CONFIG` avec tes valeurs :
```js
const FIREBASE_CONFIG = {
  apiKey: "AIzaSy...",
  authDomain: "mon-site-perso-xxxxx.firebaseapp.com",
  projectId: "mon-site-perso-xxxxx",
  storageBucket: "mon-site-perso-xxxxx.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef"
};
```

---

## 📧 ÉTAPE 3 — Configurer EmailJS (notifications email)

> EmailJS permet d'envoyer des emails sans serveur. Gratuit jusqu'à 200 emails/mois.

### 3.1 Créer un compte
1. Va sur [emailjs.com](https://www.emailjs.com) → **Sign Up** (gratuit)

### 3.2 Ajouter un service email
1. **Email Services** → **Add New Service**
2. Choisis **Gmail** (ou autre)
3. Connecte ton compte Gmail → Nomme-le `mon_service`
4. Note le **Service ID** (ex: `service_abc123`)

### 3.3 Créer un template
1. **Email Templates** → **Create New Template**
2. Configure ainsi :
   - **To Email** : `{{to_email}}`
   - **Subject** : `✅ Nouvelle réponse à ta question !`
   - **Content** :
     ```
     Bonjour {{to_name}} !

     Tu avais posé la question :
     "{{question}}"

     Voici la réponse :
     {{answer}}

     — Ton Site
     ```
3. **Save** → Note le **Template ID** (ex: `template_xyz789`)

### 3.4 Récupérer la clé publique
1. **Account** → onglet **General** → **Public Key**
2. Note cette clé (ex: `user_XXXXXXX`)

### 3.5 Ajouter EmailJS dans index.html
Avant la fermeture de `</head>`, ajoute :
```html
<script src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"></script>
```

### 3.6 Coller dans app.js
```js
const EMAILJS_CONFIG = {
  serviceId: "service_abc123",
  templateId: "template_xyz789",
  publicKey: "user_XXXXXXX"
};
```

---

## 🔑 ÉTAPE 4 — Changer le mot de passe admin

Dans `src/app.js`, ligne :
```js
const ADMIN_PASSWORD = "change-moi-2025!";
```
Change-le par quelque chose de solide. **Ne le partage jamais.**

Pour accéder au panel admin sur ton site : clic sur ⚙️ en bas de page.

---

## 🚀 ÉTAPE 5 — Déployer sur GitHub Pages

### 5.1 Créer le dépôt GitHub
1. Va sur [github.com/new](https://github.com/new)
2. Nom du dépôt : `ton-pseudo.github.io` (remplace `ton-pseudo` par ton username GitHub)
3. **Public** → Créer

### 5.2 Uploader les fichiers
Option A — Interface web :
1. Dans le dépôt → **Add file** → **Upload files**
2. Glisse tout le contenu du dossier `portfolio-site`
3. **Commit changes**

Option B — Git en ligne de commande :
```bash
cd portfolio-site
git init
git add .
git commit -m "🚀 Initial deploy"
git branch -M main
git remote add origin https://github.com/TON-PSEUDO/ton-pseudo.github.io.git
git push -u origin main
```

### 5.3 Activer GitHub Pages
1. Dans le dépôt → **Settings** → **Pages**
2. Source : **Deploy from a branch**
3. Branch : `main` / `/ (root)` → **Save**
4. Ton site sera disponible sur `https://ton-pseudo.github.io` en quelques minutes !

---

## 🔁 Déploiement automatique

Le fichier `.github/workflows/deploy.yml` est inclus.
Chaque fois que tu `push` sur `main`, le site se redéploie automatiquement.

---

## 🎨 Personnalisation avancée

### Changer les couleurs
Dans `src/styles/main.css`, modifie les variables :
```css
:root {
  --accent: #c8f04a;   /* Couleur principale (vert-jaune) */
  --accent2: #7c6af7;  /* Couleur secondaire (violet) */
  --accent3: #f04a8c;  /* Couleur d'accent (rose) */
  --bg: #0a0a0f;       /* Fond principal */
}
```

### Ajouter un réseau social
Dans `index.html`, copie-colle un bloc `.social-card` et modifie :
- `data-platform="nom"` — pour les couleurs hover
- Le SVG de l'icône (trouve-les sur [simpleicons.org](https://simpleicons.org))
- Le `href`, nom et handle

### Ajouter une couleur de hover pour un nouveau réseau
Dans `main.css`, ajoute :
```css
.social-card[data-platform="linkedin"]::before { background: linear-gradient(135deg, rgba(0,119,181,0.2), transparent); }
.social-card[data-platform="linkedin"]:hover { box-shadow: 0 20px 40px rgba(0,119,181,0.2); }
```

---

## ❓ Questions fréquentes

**Q : Le site fonctionne sans Firebase ?**
Oui ! En mode démo, tout s'affiche mais les questions ne sont pas sauvegardées.

**Q : Je peux utiliser un autre hébergeur ?**
Oui ! Le site est en HTML/CSS/JS pur. Il fonctionne sur Netlify, Vercel, OVH, etc.

**Q : Comment sécuriser davantage Firestore ?**
Après 30 jours, les règles "mode test" expirent. Mets à jour les règles de sécurité comme indiqué à l'étape 2.3.

---

## 📄 Licence

Libre d'utilisation et de modification personnelle.
